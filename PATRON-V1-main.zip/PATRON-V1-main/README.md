<p align="center">  
  <a href="">
    <img alt="𝚸𝚫𝚻𝚪𝚯𝚴 𝛁1 𝚩𝐔𝐆" height="300" src="https://telegra.ph/file/551d68eb74a30dda96c0c.jpg">
    <h1 align="center">𝚸𝚫𝚻𝚪𝚯𝚴 𝛁1 𝚩𝐔𝐆</h1>
  </a>
</p>
<p align="center">
<a href="https://t.me/textpatron_bot"><img title="Author" src="https://img.shields.io/badge/PATRON-BOT-black?style=for-the-badge&logo=telegram"></a>
<p/>


> If y'all get any suggestions, click the patron bot

####  
𝚸𝚫𝚻𝚪𝚯𝚴 𝛁1 𝚩𝐔𝐆 Whatsapp crasher Multi Device whatsapp bot.
<p align="center"><img src="https://profile-counter.glitch.me/{PATRON-V1}/count.svg" alt="itzpatron :: Visitor's Count" /></p>

***

 #### For more deployment platform join channel for update


SUPPORT CHANNEL: <a href="https://whatsapp.com/channel/0029Val0s0rIt5rsIDPCoD2q"><img alt="WhatsApp" src="https://img.shields.io/badge/Join CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

***

TESTING GROUP: <a href="https://chat.whatsapp.com/HSC7DAJOD9nBKbl7CmxxLb"><img alt="WhatsApp" src="https://img.shields.io/badge/JOIN GROUP-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

#### SETUP

1. Fork the repo
    <br>
<a href='https://github.com/patronffx/PATRON-V1/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>



2. Get Cred.json 
   
    
     <a href='https://replit.com/@Itzpatron/Patron-Pairing' target="_blank"><img alt='CRED JSON' src='https://img.shields.io/badge/Cred.json-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

## Watch Tutorial videos.
* [![YOUTUBE](https://img.shields.io/badge/HOW_TO_DEPLOY-PANEL-blue?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/ELsmTeFsHsI?si=-SP-FDYaels_0zEO)


#### DEPLOY TO CODESPACE

3. If You don't have a account in Codespace. Create a account.
    <br>
<a href='https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcodespaces' target="_blank"><img alt='Codespaces' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>

4. Now Deploy
    <br>
<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>


#### DEPLOY TO Toystack

1. If You don't have an account in Toystack. Create an account.
    <br>
<p align="center"><a href="https://toystack.ai"> <img src="https://img.shields.io/badge/Toystack%20Account-blue?style=for-the-badge&logo=Toystack" width="220" height="38.45"/></a></p>

#### DEPLOY TO HEROKU(no ban)

1. If You don't have an account in Heroku. Create a account.
    <br>
<p align="center"><a href="https://signup.heroku.com"> <img src="https://img.shields.io/badge/heroku%20Account-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
## `BUILDPACKS FOR HEROKU`

```
bash heroku/nodejs
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

#### DEPLOY TO KOYEB

1. AINT AVAILABLE FOR NOW


#### DEPLOY TO PANEL
1. Fork the repo
2. Edit then Download your forked repo zip
3. 🖥 Go to panel and upload your Sc.
4. Extract or move it to a directory (container).
5. ⌨ Use the following code to move into a container: "../"
6. Then go to the console and press Start.
   
- Note: I recommend using starter + or higher for a fast bot


#### DEPLOY TO RENDER
AINT AVAILABLE FOR NOW


#### COPY THESE COMMANDS AND PASTE IF YOU TRYING TO DEPLOY [PATRON-V1](https://github.com/Itzpatron/PATRON-V1) ON ANY TERMINAL

```
sudo apt -y update && sudo apt -y upgrade
```
```
sudo apt -y install git ffmpeg curl
```
```
curl -fsSL https://deb.nodesource.com/setup_20.x -o nodesource_setup.sh
```
```
sudo -E bash nodesource_setup.sh
```
```
sudo apt-get install -y nodejs
```
```
sudo npm install -g yarn
```
```
sudo yarn global add pm2
```
```
git clone https://github.com/type-your-username-here/PATRON-V1
```
```
cd PATRON-V1
yarn install 
npm start
```

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
# Termux Deployment

```
termux-setup-storage
```
```
apt update
```
```
apt upgrade
```
```
git clone (copy and paste your forked repo link not mine to save your changes) 
```
```
cd PATRON-V1
```
```
yarn install
```
```
npm start
```


- Star ⭐ the repo if you like 𝚸𝚫𝚻𝚪𝚯𝚴 𝛁1 𝚩𝐔𝐆.


## `Main Dev` 
<a href="https://github.com/Itzpatron"><img src="https://telegra.ph/file/551d68eb74a30dda96c0c.jpg" width="250" height="250" alt="PATRON 🚹"/></a>
<a href="https://github.com/asmakev930h"><img src="https://telegra.ph/file/229312c344db0a90bca65.jpg" width="250" height="250" alt="BLUE DEMON"/></a>

`𝚸𝚫𝚻𝚪𝚯𝚴 𝛁1 𝚩𝐔𝐆 BY 𝙿𝙰𝚃𝚁𝙾𝙽 & 𝙱𝙻𝚄𝙴 𝙳𝙴𝙼𝙾𝙽`

<h2 align="center">  Reminder
</h2>

## 
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.
- use this bot with wisdom if any report of misusing this im not responsible and you will bear for the consiquences 
